from random import randint
import time
from enum import IntEnum

# 定义棋盘上不同棋子的类型
class MAP_ENTRY_TYPE(IntEnum):
    MAP_EMPTY = 0  # 空位置
    MAP_PLAYER_ONE = 1  # 玩家1的棋子
    MAP_PLAYER_TWO = 2  # 玩家2的棋子

AI_SEARCH_DEPTH = 1  # AI搜索深度

# 定义不同棋型的枚举类型
class CHESS_TYPE(IntEnum):
    NONE = 0,  # 无棋型
    SLEEP_TWO = 1,  # 眠二
    LIVE_TWO = 2,  # 活二
    SLEEP_THREE = 3  # 眠三
    LIVE_THREE = 4,  # 活三
    CHONG_FOUR = 5,  # 冲四
    LIVE_FOUR = 6,  # 活四
    LIVE_FIVE = 7  # 活五

CHESS_TYPE_NUM = 8  # 棋型的数量

# 定义棋型的值
FIVE = CHESS_TYPE.LIVE_FIVE.value
FOUR, THREE, TWO = CHESS_TYPE.LIVE_FOUR.value, CHESS_TYPE.LIVE_THREE.value, CHESS_TYPE.LIVE_TWO.value
SFOUR, STHREE, STWO = CHESS_TYPE.CHONG_FOUR.value, CHESS_TYPE.SLEEP_THREE.value, CHESS_TYPE.SLEEP_TWO.value

SCORE_MAX = 0x7fffffff  # 分数最大值
SCORE_MIN = -1 * SCORE_MAX  # 分数最小值
SCORE_FIVE = 100000  # 活五的分数

class ChessAI():
    def __init__(self, chess_len):
        self.len = chess_len
        # [水平，垂直，左斜线，右斜线]
        self.record = [[[0,0,0,0] for x in range(chess_len)] for y in range(chess_len)]
        self.count = [[0 for x in range(CHESS_TYPE_NUM)] for i in range(2)]
        self.pos_score = [[(7 - max(abs(x - 7), abs(y - 7))) for x in range(chess_len)] for y in range(chess_len)]

    def reset(self):
        # 重置记录和计数器
        for y in range(self.len):
            for x in range(self.len):
                for i in range(4):
                    self.record[y][x][i] = 0

        for i in range(len(self.count)):
            for j in range(len(self.count[0])):
                self.count[i][j] = 0

    def click(self, map, x, y, turn):
        # 玩家点击棋盘
        map.click(x, y, turn)

    def isWin(self, board, turn):
        # 判断是否胜利
        return self.evaluate(board, turn, True)

    # 检查在半径范围内是否有非空位置
    def hasNeighbor(self, board, x, y, radius):
        start_x, end_x = (x - radius), (x + radius)
        start_y, end_y = (y - radius), (y + radius)

        for i in range(start_y, end_y+1):
            for j in range(start_x, end_x+1):
                if i >= 0 and i < self.len and j >= 0 and j < self.len:
                    if board[i][j] != 0:
                        return True
        return False

    # 获取所有靠近棋子的位置
    def genmove(self, board, turn):
        fives = []
        mfours, ofours = [], []
        msfours, osfours = [], []
        if turn == MAP_ENTRY_TYPE.MAP_PLAYER_ONE:
            mine = 1
            opponent = 2
        else:
            mine = 2
            opponent = 1

        moves = []
        radius = 1

        for y in range(self.len):
            for x in range(self.len):
                if board[y][x] == 0 and self.hasNeighbor(board, x, y, radius):
                    score = self.pos_score[y][x]
                    moves.append((score, x, y))

        moves.sort(reverse=True)

        return moves

    def __search(self, board, turn, depth, alpha = SCORE_MIN, beta = SCORE_MAX):
        # AI搜索算法的核心函数
        score = self.evaluate(board, turn)
        if depth <= 0 or abs(score) >= SCORE_FIVE:
            return score

        moves = self.genmove(board, turn)
        bestmove = None
        self.alpha += len(moves)

        # 如果没有可走的棋，直接返回分数
        if len(moves) == 0:
            return score

        for _, x, y in moves:
            board[y][x] = turn

            if turn == MAP_ENTRY_TYPE.MAP_PLAYER_ONE:
                op_turn = MAP_ENTRY_TYPE.MAP_PLAYER_TWO
            else:
                op_turn = MAP_ENTRY_TYPE.MAP_PLAYER_ONE

            score = - self.__search(board, op_turn, depth - 1, -beta, -alpha)

            board[y][x] = 0
            self.belta += 1

            # 进行alpha-beta剪枝
            if score > alpha:
                alpha = score
                bestmove = (x, y)
                if alpha >= beta:
                    break

        if depth == self.maxdepth and bestmove:
            self.bestmove = bestmove

        return alpha

    def search(self, board, turn, depth = 4):
        # 外部调用的搜索函数
        self.maxdepth = depth
        self.bestmove = None
        score = self.__search(board, turn, depth)
        x, y = self.bestmove
        return score, x, y

    def findBestChess(self, board, turn):
        # 找到最佳棋步
        time1 = time.time()
        self.alpha = 0
        self.belta = 0
        score, x, y = self.search(board, turn, AI_SEARCH_DEPTH)
        time2 = time.time()
        print('time[%.2f] (%d, %d), score[%d] alpha[%d] belta[%d]' % ((time2-time1), x, y, score, self.alpha, self.belta))
        return (x, y)



    # 计算分数
    def getScore(self, mine_count, opponent_count):
        mscore, oscore = 0, 0
        SCORE_MAX = 0x7fffffff  # 分数最大值

        # 直接成五子的高分值
        if mine_count[FIVE] > 0:
            return (SCORE_MAX-100, 0)  # 本方直接成五子
        if opponent_count[FIVE] > 0:
            return (0, SCORE_MAX-1000)  # 对手直接成五子

        # 增加活四和冲四的分数权重，但减少其影响力以避免过度反应
        if mine_count[SFOUR] >= 2:
            mine_count[FOUR] += 1
        if opponent_count[SFOUR] >= 2:
            opponent_count[FOUR] += 1

        # 本方活四和冲四的高分值
        if mine_count[FOUR] > 0:
            return (10000, 0)  # 本方活四
        if mine_count[SFOUR] > 0:
            return (6000, 0)  # 本方冲四

        # 对手活四和冲四的高分值
        if opponent_count[FOUR] > 0:
            return (0, 7500)  # 对手活四
        if opponent_count[SFOUR] > 0 and opponent_count[THREE] > 0:
            return (0, 6200)  # 对手冲四和活三

        # 本方活三的高分值，特别是当对手没有冲四时
        if mine_count[THREE] > 0 and opponent_count[SFOUR] == 0:
            return (5500, 0)  # 本方活三且对手没有冲四

        # 对手两个活三的情况，特别是本方没有活三和眠三时
        if opponent_count[THREE] > 1 and mine_count[THREE] == 0 and mine_count[STHREE] == 0:
            return (0, 5800)  # 对手两个活三且本方没有活三和眠三

        # 对手冲四的中等分数
        if opponent_count[SFOUR] > 0:
            oscore += 500  # 对手冲四

        # 本方活三和眠三的分数
        if mine_count[THREE] > 1:
            mscore += 400  # 本方两个活三
        elif mine_count[THREE] > 0:
            mscore += 200  # 本方一个活三

        if opponent_count[THREE] > 1:
            oscore += 1200  # 对手两个活三
        elif opponent_count[THREE] > 0:
            oscore += 300  # 对手一个活三

        # 本方和对手眠三的分数
        if mine_count[STHREE] > 0:
            mscore += mine_count[STHREE] * 30
        if opponent_count[STHREE] > 0:
            oscore += opponent_count[STHREE] * 30

        # 本方和对手活二的分数
        if mine_count[TWO] > 0:
            mscore += mine_count[TWO] * 20
        if opponent_count[TWO] > 0:
            oscore += opponent_count[TWO] * 20

        # 本方和对手眠二的分数
        if mine_count[STWO] > 0:
            mscore += mine_count[STWO] * 10
        if opponent_count[STWO] > 0:
            oscore += opponent_count[STWO] * 10

        return (mscore, oscore)

    def evaluate(self, board, turn, checkWin=False):
        # 评估棋盘状态
        self.reset()

        if turn == MAP_ENTRY_TYPE.MAP_PLAYER_ONE:
            mine = 1
            opponent = 2
        else:
            mine = 2
            opponent = 1

        for y in range(self.len):
            for x in range(self.len):
                if board[y][x] == mine:
                    self.evaluatePoint(board, x, y, mine, opponent)
                elif board[y][x] == opponent:
                    self.evaluatePoint(board, x, y, opponent, mine)

        mine_count = self.count[mine-1]
        opponent_count = self.count[opponent-1]
        if checkWin:
            return mine_count[FIVE] > 0
        else:
            mscore, oscore = self.getScore(mine_count, opponent_count)
            return (mscore - oscore)

    def evaluatePoint(self, board, x, y, mine, opponent, count=None):
        # 评估单个点的棋型
        dir_offset = [(1, 0), (0, 1), (1, 1), (1, -1)]  # 从左到右的方向
        ignore_record = True
        if count is None:
            count = self.count[mine-1]
            ignore_record = False
        for i in range(4):
            if self.record[y][x][i] == 0 or ignore_record:
                self.analysisLine(board, x, y, i, dir_offset[i], mine, opponent, count)

    # 固定长度为9的线：XXXXMXXXX
    def getLine(self, board, x, y, dir_offset, mine, opponent):
        # 获取一条线上的棋子状态
        line = [0 for i in range(9)]

        tmp_x = x + (-5 * dir_offset[0])
        tmp_y = y + (-5 * dir_offset[1])
        for i in range(9):
            tmp_x += dir_offset[0]
            tmp_y += dir_offset[1]
            if (tmp_x < 0 or tmp_x >= self.len or
                    tmp_y < 0 or tmp_y >= self.len):
                line[i] = opponent  # 设置范围外为对手棋子
            else:
                line[i] = board[tmp_y][tmp_x]

        return line

    def analysisLine(self, board, x, y, dir_index, dir, mine, opponent, count):
        # 分析一条线上的棋型
        # 记录已分析的线段[left, right]
        def setRecord(self, x, y, left, right, dir_index, dir_offset):
            tmp_x = x + (-5 + left) * dir_offset[0]
            tmp_y = y + (-5 + left) * dir_offset[1]
            for i in range(left, right+1):
                tmp_x += dir_offset[0]
                tmp_y += dir_offset[1]
                self.record[tmp_y][tmp_x][dir_index] = 1

        empty = MAP_ENTRY_TYPE.MAP_EMPTY.value
        left_idx, right_idx = 4, 4

        line = self.getLine(board, x, y, dir, mine, opponent)

        while right_idx < 8:
            if line[right_idx+1] != mine:
                break
            right_idx += 1
        while left_idx > 0:
            if line[left_idx-1] != mine:
                break
            left_idx -= 1

        left_range, right_range = left_idx, right_idx
        while right_range < 8:
            if line[right_range+1] == opponent:
                break
            right_range += 1
        while left_range > 0:
            if line[left_range-1] == opponent:
                break
            left_range -= 1

        chess_range = right_range - left_range + 1
        if chess_range < 5:
            setRecord(self, x, y, left_range, right_range, dir_index, dir)
            return CHESS_TYPE.NONE

        setRecord(self, x, y, left_idx, right_idx, dir_index, dir)

        m_range = right_idx - left_idx + 1

        # M:我的棋子，P:对手棋子或范围外，X:空位
        if m_range >= 5:
            count[FIVE] += 1

        # 活四：XMMMMX
        # 冲四：XMMMMP, PMMMMX
        if m_range == 4:
            left_empty = right_empty = False
            if line[left_idx-1] == empty:
                left_empty = True
            if line[right_idx+1] == empty:
                right_empty = True
            if left_empty and right_empty:
                count[FOUR] += 1
            elif left_empty or right_empty:
                count[SFOUR] += 1

        # 冲四：MXMMM, MMMXM，两种情况都可能存在
        # 活三：XMMMXX, XXMMMX
        # 眠三：PMMMX, XMMMP, PXMMMXP
        if m_range == 3:
            left_empty = right_empty = False
            left_four = right_four = False
            if line[left_idx-1] == empty:
                if line[left_idx-2] == mine:  # MXMMM
                    setRecord(self, x, y, left_idx-2, left_idx-1, dir_index, dir)
                    count[SFOUR] += 1
                    left_four = True
                left_empty = True

            if line[right_idx+1] == empty:
                if line[right_idx+2] == mine:  # MMMXM
                    setRecord(self, x, y, right_idx+1, right_idx+2, dir_index, dir)
                    count[SFOUR] += 1
                    right_four = True
                right_empty = True

            if left_four or right_four:
                pass
            elif left_empty and right_empty:
                if chess_range > 5:  # XMMMXX, XXMMMX
                    count[THREE] += 1
                else:  # PXMMMXP
                    count[STHREE] += 1
            elif left_empty or right_empty:  # PMMMX, XMMMP
                count[STHREE] += 1

        # 冲四：MMXMM，只检查右方向
        # 活三：XMXMMX, XMMXMX 两种情况都可能存在
        # 眠三：PMXMMX, XMXMMP, PMMXMX, XMMXMP
        # 活二：XMMX
        # 眠二：PMMX, XMMP
        if m_range == 2:
            left_empty = right_empty = False
            left_three = right_three = False
            if line[left_idx-1] == empty:
                if line[left_idx-2] == mine:
                    setRecord(self, x, y, left_idx-2, left_idx-1, dir_index, dir)
                    if line[left_idx-3] == empty:
                        if line[right_idx+1] == empty:  # XMXMMX
                            count[THREE] += 1
                        else:  # XMXMMP
                            count[STHREE] += 1
                        left_three = True
                    elif line[left_idx-3] == opponent:  # PMXMMX
                        if line[right_idx+1] == empty:
                            count[STHREE] += 1
                            left_three = True

                left_empty = True

            if line[right_idx+1] == empty:
                if line[right_idx+2] == mine:
                    if line[right_idx+3] == mine:  # MMXMM
                        setRecord(self, x, y, right_idx+1, right_idx+2, dir_index, dir)
                        count[SFOUR] += 1
                        right_three = True
                    elif line[right_idx+3] == empty:
                        #setRecord(self, x, y, left_idx, right_idx+2, dir_index, dir)
                        if left_empty:  # XMMXMX
                            count[THREE] += 1
                        else:  # PMMXMX
                            count[STHREE] += 1
                        right_three = True
                    elif left_empty:  # XMMXMP
                        count[STHREE] += 1
                        right_three = True

                right_empty = True

            if left_three or right_three:
                pass
            elif left_empty and right_empty:  # XMMX
                count[TWO] += 1
            elif left_empty or right_empty:  # PMMX, XMMP
                count[STWO] += 1

        # 活二：XMXMX, XMXXMX 只检查右方向
        # 眠二：PMXMX, XMXMP
        if m_range == 1:
            left_empty = right_empty = False
            if line[left_idx-1] == empty:
                if line[left_idx-2] == mine:
                    if line[left_idx-3] == empty:
                        if line[right_idx+1] == opponent:  # XMXMP
                            count[STWO] += 1
                        left_empty = True

                    if line[right_idx+1] == empty:
                        if line[right_idx+2] == mine:
                            if line[right_idx+3] == empty:
                                if left_empty:  # XMXMX
                                    #setRecord(self, x, y, left_idx, right_idx+2, dir_index, dir)
                                    count[TWO] += 1
                                else:  # PMXMX
                                    count[STWO] += 1
                        elif line[right_idx+2] == empty:
                            if line[right_idx+3] == mine and line[right_idx+4] == empty:  # XMXXMX
                                count[TWO] += 1

                return CHESS_TYPE.NONE