import pygame
from pygame import font
import renji
import kimi
# 初始化Pygame和混音器
pygame.init()
pygame.mixer.init()

# 加载音效
drop_sound = pygame.mixer.Sound("../sounds/down.mp3")  # 落子声音
win_sound = pygame.mixer.Sound("../sounds/win.mp3")  # 获胜音效

# 设置屏幕大小
screen_width = 600
screen_height = 630
screen = pygame.display.set_mode((screen_width, screen_height))

# 设置标题
pygame.display.set_caption('五子棋')

# 设置颜色
background_color = [238, 154, 73]  # 背景颜色
line_color = [0, 0, 0]  # 线颜色
white_color = [255, 255, 255]  # 白棋颜色
black_color = [0, 0, 0]  # 黑棋颜色

score = 0  # 记录分数
over_pos = []  # 记录已落子的位置及颜色
current_color = black_color  # 当前棋子颜色，初始为黑色
board = [[0] * 15 for _ in range(15)]  # 初始化棋盘数组

ai = renji.ChessAI(15)  # 初始化AI


# 棋子复位
def init():
    global over_pos, current_color, score, board
    over_pos = []  # 清空棋盘
    current_color = black_color  # 重置当前棋子颜色
    board = [[0] * 15 for _ in range(15)]  # 重置棋盘数组


# 打印文字
def print_word(word_size, word_content, word_color, word_position):
    word_font = pygame.font.SysFont('Microsoft YaHei', word_size)  # 创建字体对象
    word_text = word_font.render(word_content, True, word_color)  # 渲染文本
    text_width = word_text.get_width()  # 获取文本宽度
    text_height = word_text.get_height()  # 获取文本高度
    # 计算居中位置
    x = word_position[0] - text_width // 2
    y = word_position[1] - text_height // 2
    screen.blit(word_text, (x, y))  # 绘制文本


# 绘制棋盘
def draw_board():
    for x in range(15):
        pygame.draw.line(screen, line_color, (20 + x * 40, 50), (20 + x * 40, 610))
    for y in range(15):
        pygame.draw.line(screen, line_color, (20, 50 + y * 40), (580, 50 + y * 40))


# 加载图片
try:
    win_image_people = pygame.image.load('../images/doge.gif')  # 人类胜利图片路径
    win_image_computer = pygame.image.load('../images/smale.gif')  # 电脑胜利图片路径
except pygame.error as e:
    print(f"无法加载图片：{e}")
    run_first = False
    run_second = False


# 显示胜利图片并等待玩家点击继续
def show_win_screen(win_image, add):
    # 确定新的尺寸，将图像放大两倍
    new_width = win_image.get_width() * 2
    new_height = win_image.get_height() * 2
    # 缩放图像
    scaled_win_image = pygame.transform.scale(win_image, (new_width, new_height))
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                init()  # 重置游戏状态，准备新一局
                return False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                init()  # 重置游戏状态，准备新一局
                return True  # 玩家点击后返回游戏主循环，准备新一局
        # 绘图
        screen.blit(scaled_win_image,
                    (300 - scaled_win_image.get_width() // 2, 325 - scaled_win_image.get_height() // 2))
        # 在屏幕上显示文字
        print_word(40, add, (255, 25, 25), (screen_width // 2, screen_height // 2 + 100))
        # 显示
        pygame.display.flip()
        # 控制频率
        pygame.time.Clock().tick(60)


# 保存分数
def save_score(score):
    with open('score.txt', 'w') as file:
        file.write(str(score))


# 读取分数
def load_score():
    try:
        with open('score.txt', 'r') as file:
            return int(file.read())
    except FileNotFoundError:
        return 0  # 如果文件不存在，返回0


# 绘制撤回按钮
def draw_undo_button():
    pygame.draw.rect(screen, (255, 0, 0), (15, 10, 50, 25), 0)  # 红色按钮
    print_word(20, "撤回", (255, 255, 255), (38, 20))  # 调整文字位置


def undo_move():
    global over_pos, board, current_color
    if len(over_pos) >= 2:  # 确保至少有两个棋子可以撤回
        last_move_black = over_pos.pop()  # 移除最后一个黑棋
        last_move_white = over_pos.pop()  # 移除最后一个白棋
        x_black, y_black, color_black = last_move_black
        x_white, y_white, color_white = last_move_white
        board[(y_black - 50) // 40][(x_black - 20) // 40] = 0  # 重置棋盘数组
        board[(y_white - 50) // 40][(x_white - 20) // 40] = 0  # 重置棋盘数组
        if color_black == black_color:
            current_color = white_color  # 切换到另一种颜色
        else:
            current_color = black_color


# 检查是否有五子连线
def check_win(x, y, color):
    directions = [(0, 1), (1, 0), (1, 1), (1, -1)]  # 四个方向：水平、垂直、两个对角线
    for dx, dy in directions:
        count = 1  # 包括刚下的那一颗
        # 正方向检查
        for i in range(1, 5):
            if (x + i * dx * 40, y + i * dy * 40, color) in over_pos:
                count += 1
            else:
                break
        # 反方向检查
        for i in range(1, 5):
            if (x - i * dx * 40, y - i * dy * 40, color) in over_pos:
                count += 1
            else:
                break
        # 如果连成五个，则返回True
        if count >= 5:
            return True
    return False


# 游戏主循环
score = load_score()
chat_ai = kimi.kimi_ai()
word_ai = chat_ai.chat(f"请送给玩家一句玩五子棋的祝福语，以欢迎玩家参与五子棋对决，内容诙谐幽默，不超10字，目前玩家分数:{score}")
start = True
run_first = False
run_second = False
while start:
    # 事件处理
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            init()  # 重置游戏状态，准备新一局
            pygame.quit()
            quit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            if ((screen_width // 2) - 100 <= x <= (screen_width // 2) + 100) and (250 <= y <= 290):
                run_first = True
                run_second = False
            elif ((screen_width // 2) - 100 <= x <= (screen_width // 2) + 100) and (335 <= y <= 375):
                run_first = False
                run_second = True
    screen.fill(background_color)
    print_word(50, "五子棋", (0, 0, 0), (screen_width // 2, 100))
    print_word(20, word_ai, (0, 0, 0), (screen_width // 2, 200))
    # 绘制双人游戏按钮
    pygame.draw.rect(screen, (102, 204, 255), ((screen_width // 2) - 100, 250, 200, 40), 0)  # 浅蓝色按钮
    # 绘制人机游戏按钮
    pygame.draw.rect(screen, (0, 138, 0), ((screen_width // 2) - 100, 335, 200, 40), 0)  # 浅绿色按钮
    print_word(20, "双人对局", (0, 0, 0), (screen_width // 2, 268))
    print_word(20, "人机对局", (255, 255, 255), (screen_width // 2, 353))
    # 显示
    pygame.display.flip()
    # 控制游戏刷新速度
    pygame.time.Clock().tick(60)
    while run_first:
        # 填充背景色
        screen.fill(background_color)
        # 绘制棋盘
        draw_board()
        # 绘制所有棋子
        for pos in over_pos:
            x, y, color = pos
            pygame.draw.circle(screen, color, (x, y), 15)
        draw_undo_button()  # 绘制撤回按钮
        # 检查事件
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                init()  # 重置游戏状态，准备新一局
                run_first = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if 15 <= event.pos[0] <= 65 and 10 <= event.pos[1] <= 35:  # 撤回按钮区域
                    undo_move()  # 执行撤回操作
                    continue
                mouse_x, mouse_y = event.pos
                # 计算棋子的屏幕坐标
                grid_x = 20 + (mouse_x // 40) * 40
                grid_y = 50 + ((mouse_y - 30) // 40) * 40
                # 判断当前位置是否有棋子
                if (grid_x, grid_y, white_color) not in over_pos and (
                grid_x, grid_y, black_color) not in over_pos and grid_y >= 50:
                    # 绘制棋子
                    pygame.draw.circle(screen, current_color, (grid_x, grid_y), 15)
                    drop_sound.play()  # 播放落子声音
                    # 记录棋子位置
                    over_pos.append((grid_x, grid_y, current_color))
                    # 更新棋盘数组
                    board[(grid_y - 50) // 40][(grid_x - 20) // 40] = 1 if current_color == black_color else 2
                    # 检查是否有五子连线
                    if check_win(grid_x, grid_y, current_color):
                        if current_color == black_color:
                            win_sound.play()  # 播放获胜音效
                            # 在屏幕中央显示图片1，并在这里阻塞，点击继续运行，并重开一局
                            show_win_screen(win_image_people, "Black wins!")  # 显示黑棋胜利图片
                        else:
                            win_sound.play()  # 播放获胜音效
                            # 在屏幕中央显示图片2，并在这里阻塞，点击继续运行，并重开一局
                            show_win_screen(win_image_people, "White wins!")  # 显示白棋胜利图片
                        continue

                    # 颜色反转
                    if current_color == black_color:
                        current_color = white_color
                    else:
                        current_color = black_color
        # 显示
        pygame.display.flip()
        # 控制游戏刷新速度
        pygame.time.Clock().tick(60)
    while run_second:
        # 填充背景色
        screen.fill(background_color)
        # 绘制棋盘
        draw_board()
        # 绘制所有棋子
        for pos in over_pos:
            x, y, color = pos
            pygame.draw.circle(screen, color, (x, y), 15)
        # 在上面绘制分数
        print_word(26, f"SCORE:{score}", (255, 255, 255), (screen_width // 2, 24))  # 调用
        draw_undo_button()  # 绘制撤回按钮
        # 检查事件
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                init()  # 重置游戏状态，准备新一局
                run_second = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if 15 <= event.pos[0] <= 65 and 10 <= event.pos[1] <= 35:  # 撤回按钮区域
                    undo_move()  # 执行撤回操作
                    continue
                mouse_x, mouse_y = event.pos
                # 计算棋子的屏幕坐标
                grid_x = 20 + (mouse_x // 40) * 40
                grid_y = 50 + ((mouse_y - 30) // 40) * 40
                # 判断当前位置是否有棋子
                if (grid_x, grid_y, white_color) not in over_pos and (
                grid_x, grid_y, black_color) not in over_pos and grid_y >= 50:
                    # 绘制棋子（这里我们使用圆圈来代表棋子）
                    pygame.draw.circle(screen, current_color, (grid_x, grid_y), 15)
                    drop_sound.play()  # 播放落子声音
                    # 记录棋子位置
                    over_pos.append((grid_x, grid_y, current_color))
                    # 更新棋盘数组
                    board[(grid_y - 50) // 40][(grid_x - 20) // 40] = 1 if current_color == black_color else 2
                    # 检查是否有五子连线
                    if check_win(grid_x, grid_y, current_color):
                        if current_color == black_color:
                            win_sound.play()  # 播放获胜音效
                            # 在屏幕中央显示图片1，并在这里阻塞，点击按钮继续运行，并重开一局
                            show_win_screen(win_image_people, 'Black Wins!')  # 显示黑棋胜利图片
                            score += 1
                        else:
                            win_sound.play()  # 播放获胜音效
                            # 在屏幕中央显示图片2，并在这里阻塞，点击按钮继续运行，并重开一局
                            show_win_screen(win_image_computer, 'White wins!')  # 显示白棋胜利图片
                            score -= 3
                        save_score(score)
                        continue

                    # 颜色反转
                    if current_color == black_color:
                        current_color = white_color
                    else:
                        current_color = black_color
                    # AI落子
                    if current_color == white_color:
                        ai_turn = 1  # AI执白棋
                        x, y = ai.findBestChess(board, ai_turn)
                        grid_x, grid_y = 20 + x * 40, 50 + y * 40
                        over_pos.append((grid_x, grid_y, white_color))
                        pygame.draw.circle(screen, white_color, (grid_x, grid_y), 15)
                        board[y][x] = 2
                        if check_win(grid_x, grid_y, white_color):
                            win_sound.play()
                            show_win_screen(win_image_computer, 'White wins!')
                            score -= 3
                            save_score(score)
                            continue

                        current_color = black_color  # AI落子后，轮到玩家
        # 显示
        pygame.display.flip()
        # 控制游戏刷新速度
        pygame.time.Clock().tick(60)

# 退出pygame
pygame.quit()
