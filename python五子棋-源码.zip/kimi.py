from openai import OpenAI

client = OpenAI(
    api_key="请使用自己的",
    base_url="https://api.moonshot.cn/v1",
)


class kimi_ai():
    def __init__(self):
        self.history = [
            {"role": "system",
             "content": "你是 Kimi，由 Moonshot AI "
                        "提供的人工智能助手，你更擅长中文和英文的对话。你会为用户提供安全，有帮助，准确的回答。"}
        ]
    def chat(self,query):
        if not query:  # 检查查询是否为空
            return "错误：消息内容不能为空。"
        self.history.append({
        "role": "user",
        "content": query
        })
        completion = client.chat.completions.create(
            model="moonshot-v1-8k",
            messages=self.history,
            temperature=0.3,
        )
        result = completion.choices[0].message.content
        self.history.append({
            "role": "assistant",
            "content": result
        })
        return result
